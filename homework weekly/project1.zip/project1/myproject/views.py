from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib import auth

def register(request):
    return render(request,"register.html")
def login(request):
    if request.method == 'POST':
        id = request.POST.get("username")
        password = request.POST.get("password")
        user = auth.authenticate(username=id, password=password)
        if user is not None:
            auth.login(request, user)
            return HttpResponseRedirect('/home/')  # 登录成功，跳转到首页或其他页面
        else:
            return render(request, "login.html", {'error': '用户名或密码错误'})
    else:
        return render(request, "login.html")
