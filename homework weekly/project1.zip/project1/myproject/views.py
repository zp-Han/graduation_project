from django.contrib.auth import authenticate,login
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_protect
from myproject.models import client_info,Building_info
import requests
import re
from bs4 import BeautifulSoup
from django.core import serializers
@csrf_protect
def register(request):
    error = " "
    if request.method == 'POST':
        username = request.POST.get("用户名")
        password = request.POST.get("密码")
        email = request.POST.get("邮箱")
        if client_info.objects.filter(username=username).exists():
            error = "用户已存在"
        else:
            client = client_info.objects.create(username=username, password=password, email=email)
            return HttpResponse('注册成功')
        return render(request, "register.html", {'error': error})
    return render(request,"register.html")
@csrf_protect
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get("用户名")
        password = request.POST.get("密码")

        try:
            user = client_info.objects.filter(username=username,password=password)

            if user:
                return redirect('home') # 重定向到首页或其他页面
            else:
                error_message = '用户名或密码不正确'
                return render(request, 'login.html', {'error': error_message})

        except client_info.DoesNotExist:
            error_message = '用户不存在'
            return render(request, 'login.html', {'error': error_message})
    return render(request, 'login.html')

@csrf_protect
def search(request):
    if request.method == 'POST':
        city = request.POST.get("city")
        distinct = request.POST.get("district")

        for i in range(92, 102):
            num = str(i) + '/'
            url = 'https://sh.newhouse.fang.com/house/s/b' + num
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36'}
            r = requests.get(url, headers=headers)
            soup = BeautifulSoup(r.text, 'html.parser')

            for bld in soup.select('.nlc_details'):
                name = re.sub(u"([^\u4e00-\u9fa5])", "", bld.a.string)
                address = bld.select_one('.address').a.attrs['title']
                price_element = bld.select_one('.nhouse_price span')
                if price_element is not None:
                    price = price_element.string
                else:
                    price = 'N/A'  # 设置默认值或其他处理方式

                # 创建或更新模型对象
                building_info, created = Building_info.objects.get_or_create(name=name, defaults={'address': address})
                if not created:
                    # 如果对象已存在，则更新其属性
                    building_info.address = address
                building_info.price = price
                building_info.save()
                return render(request,'building_info_view.html')
    return render(request,'search.html')

def building_info_view(request):
    # 从数据库中获取Building_info对象列表
    building_infos = Building_info.objects.all()

    # 将数据转换为JSON格式供JavaScript使用
    building_data_json = serializers.serialize('json', building_infos)

    # 渲染模板并传递数据
    return render(request, 'building_info.html', {'building_infos': building_infos, 'building_data_json': building_data_json})
