from django.contrib import admin
from myproject import models

# Register your models here.
admin.site.register(models.client_info)