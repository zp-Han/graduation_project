from django.urls import path
from . import views
from django.contrib import admin
urlpatterns = [
    path('admin',admin.site.urls),
    path('login',views.login_view,name='login'),
    path('register',views.register),
    path('search',views.search,name='search'),
    path('building_info_view',views.building_info_view)
]
