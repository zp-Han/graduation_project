from django.db import models

# Create your models here.
class client_info(models.Model):
    username = models.CharField(max_length=15)
    password = models.CharField(max_length=20)
    email = models.CharField(max_length=25)

class Building_info(models.Model):
    city = models.CharField(max_length=10)
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    price = models.CharField(max_length=50)
