import requests
import re
from bs4 import BeautifulSoup
from myproject.models import Building_info  # 导入您的模型


for i in range(92, 102):
    num = str(i)+'/'
    url = 'https://newhouse.fang.com/house/s/b'+num
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36'}
    r = requests.get(url, headers=headers)
    soup = BeautifulSoup(r.text, 'html.parser')

    for bld in soup.select('.nlc_details'):
        name = re.sub(u"([^\u4e00-\u9fa5])", "", bld.a.string)
        address = bld.select_one('.address').a.attrs['title']
        price_element = bld.select_one('.nhouse_price span')
        if price_element is not None:
            price = price_element.string
        else:
            price = 'N/A'  # 设置默认值或其他处理方式

        # 创建或更新模型对象
        building_info, created = Building_info.objects.get_or_create(name=name, defaults={'address': address})
        if not created:
            # 如果对象已存在，则更新其属性
            building_info.address = address
        building_info.price = price
        building_info.save()
